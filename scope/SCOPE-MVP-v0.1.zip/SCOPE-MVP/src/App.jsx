import React,{useEffect,useState} from 'react';
const API='http://127.0.0.1:47831';
const money=v=>v==null?'—':new Intl.NumberFormat('en-US',{style:'currency',currency:'USD',maximumFractionDigits:2}).format(Number(v));
export default function App(){
  const [phase,setPhase]=useState('ready'),[result,setResult]=useState(null),[error,setError]=useState('');
  async function scopeThis(){
    setError('');setPhase('capturing');
    try{
      const capture=await window.scopeDesktop.captureScreen();setPhase('analyzing');
      const r=await fetch(`${API}/api/analyze-screen`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({imageDataUrl:capture.dataUrl})});
      const data=await r.json();if(!r.ok)throw new Error(data.error||`Analysis failed (${r.status})`);setResult(data);
    }catch(e){setError(e.message||String(e));}finally{setPhase('ready');}
  }
  useEffect(()=>window.scopeDesktop?.onScopeHotkey?.(scopeThis),[]);
  return <main className="shell">
    <header><div><small>MARKET INTELLIGENCE</small><h1>SCOPE</h1></div><button onClick={()=>window.scopeDesktop.hide()}>×</button></header>
    <button className="scan" disabled={phase!=='ready'} onClick={scopeThis}><i/><div><b>{phase==='capturing'?'Capturing…':phase==='analyzing'?'Checking market…':'Scope this'}</b><span>Ctrl + Shift + Space</span></div></button>
    <p className="privacy">Only captures your screen when you trigger SCOPE.</p>
    {error&&<div className="error">{error}</div>}
    {!result&&!error&&<section className="empty"><h2>Know the real value before you buy.</h2><p>Open a listing, product page, or bundle and press the hotkey.</p></section>}
    {result&&<>
      <section className="product"><em>{result.product?.sourceSite||'Current screen'}</em><h2>{result.product?.canonicalName}</h2><div className="chips"><span>{result.product?.condition}</span>{result.product?.variant&&<span>{result.product.variant}</span>}{result.product?.modelNumber&&<span>{result.product.modelNumber}</span>}</div></section>
      <section className={`verdict ${String(result.valuation?.verdict||'').toLowerCase().includes('deal')||result.valuation?.verdict==='Steal'?'good':result.valuation?.verdict==='Fair'?'mid':'bad'}`}><div><small>DEAL SCORE</small><strong>{Math.round(result.valuation?.dealScore||0)}</strong></div><div><b>{result.valuation?.verdict}</b><p>{result.valuation?.summary}</p></div></section>
      <section className="grid"><div><span>Asking</span><b>{money(result.product?.askingPrice)}</b></div><div><span>Fair value</span><b>{money(result.valuation?.fairValue)}</b></div><div><span>Best new</span><b>{money(result.valuation?.bestNewPrice)}</b></div><div><span>Used range</span><b>{money(result.valuation?.usedRange?.low)}–{money(result.valuation?.usedRange?.high)}</b></div></section>
      <section className="panel"><div className="row"><span>Confidence</span><b>{Math.round(result.valuation?.confidence||0)}%</b></div><div className="bar"><i style={{width:`${result.valuation?.confidence||0}%`}}/></div><p>{result.valuation?.confidenceReason}</p></section>
      {result.bundle?.isBundle&&<section className="panel"><h3>Bundle breakdown</h3>{result.bundle.components?.map((x,i)=><div className="row" key={i}><span>{x.name}</span><b>{money(x.marketNewPrice)}</b></div>)}<div className="row total"><span>Individual market total</span><b>{money(result.bundle.individualMarketTotal)}</b></div><p className="save">Saves {money(result.bundle.savings)} ({Math.round(result.bundle.savingsPercent||0)}%)</p></section>}
      <section className="panel"><div className="row"><h3>Price evidence</h3><span>{result.evidence?.length||0} comps</span></div>{(result.evidence||[]).slice(0,10).map((x,i)=><div className="offer" key={i}><div><b>{x.source}</b><span>{x.condition} · {x.type}</span></div><div><b>{money(x.totalPrice??x.price)}</b><span>{Math.round((x.matchScore||0)*100)}% match</span></div></div>)}</section>
      <section className="panel"><h3>Why</h3><p>{result.valuation?.explanation}</p></section>
    </>}
  </main>
}
