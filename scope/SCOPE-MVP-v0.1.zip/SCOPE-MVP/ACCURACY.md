# SCOPE Fair Market Value Method

1. Resolve the exact product identity before comparing price.
2. Keep condition groups separate: new, open-box, refurbished, used.
3. Treat active asking prices as weaker evidence than completed sales.
4. Never label an active listing as a sold comp.
5. Reject wrong model, generation, capacity, accessory, or bundle-state matches.
6. Filter extreme prices using median absolute deviation.
7. Calculate a weighted median, not a naive average.
8. Weight exact-match confidence, source reliability, evidence type, and verification state.
9. Report confidence based on source count, comp count, identity certainty, sold history, and market spread.
10. For bundles, compare the bundle to the sum of individual current-market component prices, not advertised MSRP.
