# SCOPE — See the real value.

SCOPE is a screen-aware desktop market intelligence overlay.

Open any product listing, retail page, marketplace post, or bundle and press:

`Ctrl + Shift + Space`

SCOPE captures the current screen only when triggered, identifies the exact product/variant/condition/asking price, searches live pricing evidence, and calculates a confidence-rated fair market value.

## MVP features

- works over any visible website
- exact product/model/variant extraction from the screen
- condition detection
- current asking price detection
- bundle/component detection
- live web pricing evidence via OpenAI web search
- optional official Best Buy near-real-time pricing adapter
- separates retail, open-box, active used, and verified sold evidence
- rejects weak model matches
- robust outlier filtering
- weighted-median fair market value
- best new price
- typical used range
- deal score
- confidence score
- bundle individual market total and true savings

## Accuracy rule

`LISTED PRICE != SOLD PRICE != FAIR MARKET VALUE`

SCOPE never treats a random active listing as proof that the item sells for that amount.

Offers below 0.78 model/variant match confidence are discarded. Extreme outliers are filtered with median absolute deviation. Verified retail and sold evidence gets higher weight than active marketplace asks.

If reliable evidence is weak, SCOPE lowers confidence instead of inventing precision.

## Run it

1. Install Node.js LTS.
2. Copy `.env.example` to `.env`.
3. Add `OPENAI_API_KEY`.
4. Optional: add `BESTBUY_API_KEY`.
5. Run:

```bash
npm install
npm run dev
```

Open a product page and press `Ctrl + Shift + Space`.

## Next adapters

- eBay Browse API current inventory
- approved eBay sold-history access if available
- Best Buy Open Box
- browser companion for DOM + current URL alongside screenshot vision
- Micro Center bundle/page parser
- UPC/GTIN identity matching
- local taxes/shipping normalization
- price history cache
- watchlists/deal alerts
- reseller mode and profit after marketplace fees
- signed Windows installer
