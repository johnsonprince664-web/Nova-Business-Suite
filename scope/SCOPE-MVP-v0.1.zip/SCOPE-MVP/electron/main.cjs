const { app, BrowserWindow, desktopCapturer, globalShortcut, ipcMain, screen } = require('electron');
const path = require('path');
let win;
function createWindow(){
  const d=screen.getPrimaryDisplay(); const width=430,height=720;
  win=new BrowserWindow({width,height,x:d.workArea.x+d.workArea.width-width-20,y:d.workArea.y+20,frame:false,alwaysOnTop:true,show:false,resizable:true,webPreferences:{preload:path.join(__dirname,'preload.cjs'),contextIsolation:true,nodeIntegration:false}});
  if(!app.isPackaged) win.loadURL('http://127.0.0.1:47830');
  else win.loadFile(path.join(__dirname,'..','dist','index.html'));
}
async function capturePrimary(){
  const d=screen.getPrimaryDisplay();
  const sources=await desktopCapturer.getSources({types:['screen'],thumbnailSize:{width:Math.max(1280,d.size.width),height:Math.max(720,d.size.height)}});
  const source=sources.find(s=>String(s.display_id)===String(d.id))||sources[0];
  if(!source) throw new Error('No display capture source available.');
  return {dataUrl:source.thumbnail.toDataURL(),displayName:source.name};
}
app.whenReady().then(()=>{
  createWindow();
  globalShortcut.register('CommandOrControl+Shift+Space',()=>{win.show();win.focus();win.webContents.send('scope:hotkey');});
});
ipcMain.handle('scope:capture-screen',capturePrimary);
ipcMain.on('scope:hide',()=>win?.hide());
app.on('will-quit',()=>globalShortcut.unregisterAll());
app.on('window-all-closed',()=>{if(process.platform!=='darwin')app.quit();});
