const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('scopeDesktop', {
  captureScreen: () => ipcRenderer.invoke('scope:capture-screen'),
  onScopeHotkey: (callback) => {
    const handler = () => callback();
    ipcRenderer.on('scope:hotkey', handler);
    return () => ipcRenderer.removeListener('scope:hotkey', handler);
  },
  hide: () => ipcRenderer.send('scope:hide'),
});
